const authrouter = require("express").Router()
const { register, loginUser, createUserByAdmin, getCompanyUser, editSettings } = require("../controllars/authcontrollar")
const { ValidateUser } = require("../middlewares/authMiddleware")


// new  user register routes
authrouter.post("/register" ,register)
authrouter.post("/create-user" , ValidateUser,createUserByAdmin)
authrouter.get("/get-company-user" , ValidateUser,getCompanyUser)
authrouter.put("/settings" , ValidateUser,editSettings)
authrouter.post("/login" ,loginUser)



module.exports = {authrouter};
